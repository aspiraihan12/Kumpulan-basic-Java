package praktikum_03;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.swing.JOptionPane;

public class GetInputFromKeyboard_04 {
	public static void main(String [] args) {
		
		BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));
		
		String name ="",hoby="";
		
		name = JOptionPane.showInputDialog("Nama Anda : ");
		hoby = JOptionPane.showInputDialog("Hobi Anda : ");
		
		String msg = "Jadi Anda Hobi"+hoby+". hobi yang bagus pak"+name;
		JOptionPane.showMessageDialog(null,msg);
		
		System.out.println("Jadi Anda Hobi "+hoby+" . hobi yang bagus pak"+name);
	}
}
