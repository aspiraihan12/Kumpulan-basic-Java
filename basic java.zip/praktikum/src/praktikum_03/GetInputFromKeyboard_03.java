package praktikum_03;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class GetInputFromKeyboard_03 {
	public static void main(String [] args) {
		BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));
		
			String name="",hoby="";
			try {
				System.out.print("Nama anda : ");
				name = dataIn.readLine();
				System.out.print("Hobi Anda :");
				hoby = dataIn.readLine();
			}catch(IOException e) {
				System.out.println("gagal membaca keyboard");
			}
			System.out.println("Jadi Anda Hobi "+ hoby +".Hobi yang bagus pak"+name);
	}
}
