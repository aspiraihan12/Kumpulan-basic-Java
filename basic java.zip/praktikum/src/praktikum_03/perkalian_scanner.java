package praktikum_03;

import java.util.Scanner;

public class perkalian_scanner {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Masukkan Bilangan Pertama :");
		int bilangan1 = input.nextInt();
		
		System.out.print("Masukkan Bilangan Kedua :");
		int bilangan2 = input.nextInt();
		
		System.out.print("Hasil perkalian: "+(bilangan1*bilangan2));
	}
}
