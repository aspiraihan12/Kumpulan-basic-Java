package praktikum_03;



	 import javax.swing.JOptionPane;

	 /**

	  *

	  * @author Azhar

	  */

	 public class JOptionPanelCalculator {

	     public static void main(String[] args) {

	         String input1;

	         String input2;

	         int nilai1;

	         int nilai2;

	         int tambah;

	         input1 = JOptionPane.showInputDialog("Masukkan nilai pertama:");

	         input2 = JOptionPane.showInputDialog("Masukkan nilai kedua:");

	         nilai1 = Integer.parseInt(input1);

	         nilai2 = Integer.parseInt(input2);

	         tambah = penjumlahan(nilai1, nilai2);

	         JOptionPane.showMessageDialog(null, "Hasil dari "+nilai1+" + "+ nilai2+" adalah " +tambah);

	     }

	     public static int penjumlahan(int nilai1, int nilai2){

	         return nilai1 + nilai2;      

	     }

	 }


