package praktikum_03;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Panel;

import javax.swing.JPanel;

public class GraphicPanel_02 extends Panel {
	
	public GraphicPanel_02(){
		setBackground(Color.yellow);
	}
	
	public void paint(Graphics g) {
		g.setColor(new Color(255,0,0));//warna untuk font hijau
		g.setFont(new Font("Calibri",Font.PLAIN,19));
		g.drawString("Hello GUI World!",30,100);
		g.setColor(new Color(1.0f,0,0));//underline teks habang
     	g.fillRect(30, 100, 150, 10);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Frame f = new Frame("Testing Graphics Panel");
		GraphicPanel_02 gp = new GraphicPanel_02();
		f.add(gp);
		f.setSize(600 , 300);
		f.setVisible(true);

	}

}
