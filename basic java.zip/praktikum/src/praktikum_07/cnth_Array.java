package praktikum_07;

public class cnth_Array {

	public static void main(String[] args) {
		String[]kota= {"Banjarmasin","Banjarbaru","Martapura","Rantau","Kandangan","Kotabaru","Batulicin","Pelaihari"};
		
		for(int i=0; i<kota.length;i++) {
			System.out.println(kota[i]);
		}

	}

}
//aspiraihan