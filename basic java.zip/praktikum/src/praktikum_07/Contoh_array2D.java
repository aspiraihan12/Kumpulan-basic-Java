package praktikum_07;

public class Contoh_array2D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] bil = {{1,2,3,4,5},
				{4,5,6,7,8},
				{7,8,9,10,11},
		};
		
		for (int i=0;i<bil.length;i++) {
			for(int j=0;j<5;j++) 
				System.out.print(bil[i][j]+ " ");
			
				System.out.println("");
			
				
		}
		
			}
}
//aspiraihan