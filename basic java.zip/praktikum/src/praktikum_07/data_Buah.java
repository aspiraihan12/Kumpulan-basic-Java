package praktikum_07;

import java.util.Scanner;

public class data_Buah {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] buah = new String[5];
	for(int i=0;i<buah.length;i++) {
		System.out.print("Masukan nama buah ke = "+i+ ":");
		Scanner input = new Scanner(System.in);
		buah[i]=input.next();
		
	}
	System.out.println("Data buah yang dimasukkan adalah");
	for(String b:buah) {
		System.out.println(b);
	}
		
	}

}
//aspiraihan