package praktikum_07;

public class ContohArray {
	public static void main(String [] args) {
		String[] kota;
		kota = new String[5];
		
		//mengisi elemen array
		kota[0]="Banjarmasin";
		kota[1]="Banjarbaru";
		kota[2]="Martapura";
		kota[3]="Rantau";
		kota[4]="Kadangan";
		
		//memanggil elemen array
		System.out.println(kota[0]);
		System.out.println(kota[1]);
		System.out.println(kota[2]);
		System.out.println(kota[3]);
		System.out.println(kota[4]);
	}
}
//aspiraihan