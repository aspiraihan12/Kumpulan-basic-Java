package praktikum_07;

public class array3Dimensi {
	public static void main(String[] args) {
		//membuat isi elemen array
		int[][][] angka = { //{kolom1,kolom2,kolom3}
				{{1,2,3},	//baris ke-0
				{4,5,6},	//baris ke-1
				{7,8,9}},	//baris ke-2
				
				{{10,11,12},	//baris ke-3
				{13,14,15}, 	//baris ke-4
				{16,17,18}}, 	//baris ke-5
				
				{{19,20,21},	//baris ke-6
				{22,23,24}, 	//baris ke-7
				{25,26,27}},	//baris ke-8
				}; //kurung kurawal array penutup
		
		//mendeklarasikan baris dan kolom
		int i,j,k; // i = baris, j = kolom
		
		for ( i=0;i<3;i++) { //menampilkan elemen sejumlah baris
			
			for(j=0;j<3;j++) {//menampilkan elemen sejumlah kolom
				
				for(k=0;k<3;k++) {
					//menampilkan isi elemen baris dan kolom
					System.out.print(angka[i][j][k]+" ");
				}
				System.out.println(""); //pindah baris
			}
			System.out.println(""); //pindah baris
		}
	}
}
//aspiraihan