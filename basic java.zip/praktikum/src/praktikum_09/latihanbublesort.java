package praktikum_09;

public class latihanbublesort {


		public static void main(String[] args) {
			int[] bil= {6,8,2,0,-3,10,4};
			System.out.println("Bilangan sebelum sorting");
			for(int i=0;i<bil.length;i++) {
			System.out.print(bil[i]+ " ");
			}
			//proses bubble sort
			for(int i=0;i<bil.length;i++) {
			for(int j=0; j<bil.length-1;j++) {
			if(bil[j]>bil[j+1]) {
			//tukar elemen
			int temp=bil[j];
			bil[j]=bil[j+1];
			bil[j+1]=temp;
			}
			}
			}
			System.out.println("\nBilangan setelah sorting");
			for(int i=0;i<bil.length;i++) {
			System.out.print(bil[i]+ " ");
			}
			}
	}


