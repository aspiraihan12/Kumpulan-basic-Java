package praktikum_09;

import java.util.Scanner;

public class ExchangeSort {

	public static void main(String[] args) {
		int[] data = new int[100]; //tipe data int data maksimal 1000
		int n;
		Scanner msk = new Scanner(System.in);
		//masukan n
		System.out.print("Masukkan jumlah data = "); //input bilangan
		n = msk.nextInt();
		
		for(int i=0;i<=n-1;i++) {
			System.out.print("Masukkan data = ");
			
			data[i]=msk.nextInt();
		}
		for(int i=0;i<n-2;i++) {
			for(int j=1;j<=n-1;j++) {
				if(data[i]>data[j]) {
					int temp=data[i];
					data[i]=data[j];
					data[j]=temp;
				}
			}
		}
		System.out.println();
		for(int i=0;i<=n-1;i++) {
			System.out.print("data telah diurutkan =");//output
			System.out.println(data[i]);
		}
	}

}
