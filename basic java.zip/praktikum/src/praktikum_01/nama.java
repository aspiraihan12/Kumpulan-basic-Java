package praktikum_01;

public class nama {
	 public static void main(String args[]){
		 String nama="M Aspi Raihan",nim="E020320068";
		 System.out.println("~~Selamat datang pada pemprograman Java");
		 System.out.println("[Nama kalian] = "+nama);
		 System.out.println("[Nim] : "+nim);
	 }

}
