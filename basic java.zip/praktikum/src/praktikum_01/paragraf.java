package praktikum_01;

public class paragraf {
	public static void main (String args[]) {
		System.out.println("java adalah salah satu bahasa pemprograman komputer yang berorientasi objek \n" 
				+"Diciptakan oleh James gosling(1995) dari perusahaan sun microsystem \n"
				+"Java diciptakan berdasarkan bahasa c++ \n"
				+"Dengan tujuan platform independeny, dapat dijalankan pada berbagai jenis hardware tanpa kompilasi ulang");
	}
}
