package praktikum_06;

import java.util.Scanner;

public class latihan {
	public static int grade;
	
	//prosedur inputan
	static void inputNilai() {
		System.out.println("Silahkan masukkan nilai =");
		Scanner x = new Scanner (System.in);
		grade = x.nextInt();
	}
	
	//prosedur logika
	static void percabangan() {
		if(grade >60) {
			System.out.println("Selamat");
			System.out.println("Anda berhasil");
		}else {
			System.out.println("maaf anda gagal");
		}
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		inputNilai();
		percabangan();
	}

}
