package praktikum_06;

public class fungsiStatic {
	//nonstatik
	void makanan(String makanan) {
		System.out.println("nama makanan "+makanan);
	}
	//fungsi statik
	static void minuman(String minuman) {
		System.out.println("saya minum"+minuman);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		minuman("kopi");
		
	//memanggil non statik
		fungsiStatic f = new fungsiStatic();
		f.makanan("Soto ayam");

	}

}
