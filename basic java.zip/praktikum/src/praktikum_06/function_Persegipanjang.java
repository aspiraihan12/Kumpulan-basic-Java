package praktikum_06;

public class function_Persegipanjang {

	static int menghitungLuas(int sisi) {
		int luas = sisi*sisi;
		return luas;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("luas persegi dengan sisi ="+menghitungLuas(4));
	}

}
