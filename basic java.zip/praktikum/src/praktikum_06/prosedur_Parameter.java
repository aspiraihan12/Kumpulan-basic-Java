package praktikum_06;

public class prosedur_Parameter {
	
	//mendeklarasikan prosedur
static void mengucapkanSalam(String ucapan,int a , double b) {
	//menampilkan teks
	System.out.println(ucapan);
	System.out.println(a);
	System.out.println(b);
	//System.out.println("Kelas Algoritma Pemprograman");
	///System.out.println("M Aspi Raihan");
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mengucapkanSalam("pagi",10,9.0);
	}

}
