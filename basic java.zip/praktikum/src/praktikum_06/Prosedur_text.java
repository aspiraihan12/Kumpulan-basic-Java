package praktikum_06;

public class Prosedur_text {
	
	//mendeklarasikan prosedur
static void menampilkanTeks() {
	//menampilkan teks
	System.out.println("Selamat pagi");
	System.out.println("Kelas Algoritma Pemprograman");
	System.out.println("M Aspi Raihan");
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		menampilkanTeks();
	}

}
