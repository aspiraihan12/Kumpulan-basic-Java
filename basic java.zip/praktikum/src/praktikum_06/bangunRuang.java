package praktikum_06;

public class bangunRuang {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s =10;
		int luas=luasKubus(s);
		System.out.println("luas kubus untuk sisi 10 adalah = "+luas);
	}
	static int luasPersegi(int sisi) {
		return sisi*sisi;
	}
	static int luasKubus(int sisi) {
		return 6*luasPersegi(sisi);
	}
}
