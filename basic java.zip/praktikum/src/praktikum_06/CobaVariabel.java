package praktikum_06;

public class CobaVariabel {
    static String nama= "Aspi raihan";
    static int absen = 10;
    
    static void menampilkanVar() {
    	String a = "belajar menampilkan variabel";
    	System.out.println(a);
    	System.out.println("nama saya adalah = "+nama);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
///memanggil prosedur
		menampilkanVar();
		
		//memanggil praibel global
		System.out.println("nama = "+nama);
		System.out.println("Absen = "+absen);
	}

}
