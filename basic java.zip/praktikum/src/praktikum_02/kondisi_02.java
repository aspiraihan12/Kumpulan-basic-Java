package praktikum_02;

public class kondisi_02 {
	public static void main(String [] args) {
		
			int score = 0;
			char answer ='a';
			
			score = (answer=='a') ? 10 : 0;
			System.out.println("Score = " + score);
		
	}
}
