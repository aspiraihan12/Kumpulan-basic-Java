package praktikum_02;

public class ElevatorTest {
	public static void main(String args[]) {
		Elevator e = new Elevator();
		 e.bukaPintu();
		 e.tutupPintu();
		 e.turun();
		 System.out.println("");
	e.naik();
	e.naik();
	e.naik();
		System.out.println("");
		e.bukaPintu();
		e.tutupPintu();
		e.turun();
		System.out.println("");
		 e.bukaPintu();
		 e.turun();
		 e.bukaPintu();
	}
}
