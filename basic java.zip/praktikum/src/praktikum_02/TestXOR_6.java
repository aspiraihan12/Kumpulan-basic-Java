package praktikum_02;

public class TestXOR_6 {
	public static void main(String[] args) {
		
		//1
		boolean val1 = true;
		boolean val2 = true;
		System.out.println(val1 ^ val2);
		
		//2
		val1=false;
		val2=true;
		System.out.println(val1 ^ val2);
		
		//3
		val1=false;
		val2=false;
		System.out.println(val1 ^ val2);
		
		//4
		val1=true;
		val2=false;
		System.out.println(val1 ^ val2);
		
	}
}
