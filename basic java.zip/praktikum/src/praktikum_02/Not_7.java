package praktikum_02;

public class Not_7 {
	public static void main (String []args) {
		boolean val1=true;
		boolean val2=false;
		
		System.out.println(!val1);
		System.out.println(!val2);
	}
}
