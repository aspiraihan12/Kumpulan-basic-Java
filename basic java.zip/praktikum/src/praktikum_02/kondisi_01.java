package praktikum_02;

public class kondisi_01 {
	public static void main(String [] args) {
		
		String status="";
		int grade = 80;
		
		//dapat status pelajar
		status = (grade >= 90 )?"passed":"Fail";
		
		//cetak status
		System.out.println(status);
	}
	
}
