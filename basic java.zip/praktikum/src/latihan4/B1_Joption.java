package latihan4;

import javax.swing.JOptionPane;

public class B1_Joption {
	public static void main(String [] args) {
		int a=0,b=0,c=0,rata=0;
		
		String input1="",input2="",input3="",hasil="",senyum="";
		
		input1 = JOptionPane.showInputDialog("Nilai 1:");
		input2 = JOptionPane.showInputDialog("Nilai 2:");
		input3 = JOptionPane.showInputDialog("Nilai 3:");
		
		a=Integer.parseInt(input1);
		b=Integer.parseInt(input2);
		c=Integer.parseInt(input3);
		rata=(a+b+c)/3;
		
		if(rata>=60) {
			senyum =" :-D";
		}else {
			senyum =" :-(";
		}
		hasil +=(hasil)+(" Menghitung rata-rata")+"\n";
		hasil +="\n";
		hasil +="Nilai 1 :"+Integer.toString(a)+"\n";
		hasil +="Nilai 2 :"+Integer.toString(b)+"\n";
		hasil +="Nilai 3 :"+Integer.toString(c)+"\n";
		
		hasil +="\n";
		hasil+="Hasil rata-rata= "+Integer.toString(rata)+"\n"+"\n";
		JOptionPane.showMessageDialog(null, hasil+"Ekspresi "+senyum);
	}
}
