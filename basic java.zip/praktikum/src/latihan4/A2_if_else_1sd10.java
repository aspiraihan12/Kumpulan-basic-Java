package latihan4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class A2_if_else_1sd10 {
	public static void main(String[] args) {
		BufferedReader dataIn = new BufferedReader(new InputStreamReader (System.in));
		String num ="";
		
		System.out.println("Masukkan angka sampai 1-10");
		
		try {
			num = dataIn.readLine();
		}catch(IOException e) {
			System.out.println("Error!");
		}
		int i = Integer.parseInt(num); //ingat untuk mengonvert String menjadi int harus menggunakan ini atau metodeyang lain
		
		switch(i) {
		case 1:
			System.out.println("satu");
			break;
		case 2:
			System.out.println("dua");
			break;
		case 3:
			System.out.println("tiga");
			break;
		case 4:
			System.out.println("empat");
			break;
		case 5:
			System.out.println("lima");
			break;
		case 6:
			System.out.println("enam");
			break;
		case 7:
			System.out.println("tuju");
			break;
		case 8:
			System.out.println("delapan");
			break;
		case 9:
			System.out.println("sembilan");
			break;
		case 10:
			System.out.println("sepuluh");
			break;
			default:
				System.out.println("Invalid number!");
	
		}
	}

}
