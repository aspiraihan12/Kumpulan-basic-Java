package latihan4;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class A1_Scanner {
	public static void main(String[] args) {
		String hasil,senyum;
		int n1,n2,n3,rata;
		
		
		Scanner input= new Scanner(System.in);
		System.out.println("PROGRAM NILAI RATA RATA");
		
		System.out.print("Nilai pertama :");
		n1=input.nextInt();
		System.out.print("Nilai kedua :");
		n2=input.nextInt();
		System.out.print("Nilai ketiga :");
		n3=input.nextInt();
		rata=(n1+n2+n3)/3;
		
		if(rata>=60) {
			senyum =" Selamat nilai nya bagus!";
		}else {
			senyum =" Maaf nilai anda kurang bagus";
		}
		System.out.println("rata rata dari tiga nilai "+rata+"\n");
		System.out.print("Ekspresi" +senyum);
		
	}
}
