package latihan_2;

public class Nilai_Terbesar02 {
	public static void main(String args[]){
        int angka1, angka2, angka3, maks;
        angka1 = 10;
        angka2 = 23;
        angka3 = 5;
        
        	// namavariabel = (pernyataan) ? true : false
        maks = (angka1>angka2)?angka1:angka2;
        maks = (maks>angka3)?maks:angka3;
        
        System.out.println("Number 1 : "+angka1);
        System.out.println("Number 2 : "+angka2);
        System.out.println("Number 3 : "+angka3);
        System.out.println("Nilai Tertinggi nya adalah = "+maks);
    }

}
