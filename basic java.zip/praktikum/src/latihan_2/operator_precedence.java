package latihan_2;

public class operator_precedence {
public static void main(String args[]) {
	System.out.println("1. a / ( b ^ ( c ^ d ) ) - e + f - ( g * h ) + 1 ");
	System.out.println("2. (3*10) * (2/15) - 2 + (4 ^ (2 ^ 2 ) )");
	System.out.println("3. ( ( ( r ^ s ) * t ) / u ) - v + ( w ^ x ) - y++");
}
}
