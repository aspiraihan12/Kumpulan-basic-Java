package latihan_2;

public class average_tugas {
	public static void main(String args[]) {
		// Deklarasi, inisialisasi variabel
	    int number1 = 10 ,
	        number2 = 20;
	        double number3 = 45.13;
	    // Menghitung nilai rata2 dan assign ke dalam variabel result    
	    double Average = (number1 + number2 + number3)/3;
	 
	    // Menampilkan hasil perhitungan
	    System.out.println("number 1 = "+number1);
	    System.out.println("number 2 = "+number2);
	    System.out.println("number 3  = "+number3);
	    System.out.println("Average is = " + Average);
	}
}
