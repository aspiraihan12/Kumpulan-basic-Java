package latihan_2;

public class deklarasi_variabel_tugas {
	public static void main(String args[]) {
		 // Deklarasi variabel
	      int number;
	      char letter;
		  boolean result;
		  String str ;
	      // Memberi nilai ke variabel
	      number = 10;
	      letter ='a';
	      result = true;
		  str="hello";
	      // Menampilkan hasil
	      System.out.println();
	      System.out.println("Number = " + number);//10
	      System.out.println("letter = " + letter);//a
	      System.out.println("result = " + result);///true
	      System.out.println("str = " + str);//hello
	}
}
