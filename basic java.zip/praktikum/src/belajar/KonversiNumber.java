
public class KonversiNumber {

	public static void main(String[] args) {
		
		byte iniByte =10;
		short iniShort = iniByte;
		int iniInt = iniShort;
		
		

	}

}
