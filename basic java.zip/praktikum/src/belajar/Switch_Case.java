import java.util.Scanner;

public class Switch_Case {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		
//		try {
			System.out.println("1 . mencari luas bangun datar");
			System.out.println("2 . Mencari volume bangun ruang");
			System.out.print("Silahkan Pilih = ");
			int jenis = sc.nextInt();
			
		switch (jenis) {
		case 1 : {
			//bangun datar
			System.out.println("1. Segitiga");
			System.out.println("2. Jajargenjang");
			System.out.print("Silahkan pilih jenis bangun datar = ");
			int bangunDatar = sc.nextInt();
		
			switch (bangunDatar) {
				case 1:{
					// Segitiga
					System.out.println("Input alas");
					double alas = sc.nextDouble();
					System.out.println("Input tinggi");
					double tinggi = sc.nextDouble();
					System.out.printf("Luas Segitiga = %.3f\n", alas * tinggi / 2.0);
					break;
				}
				case 2: {
					// Jajargenjang
					System.out.println("Input alas");
					double alas = sc.nextDouble();
					System.out.println("Input tinggi");
					double tinggi = sc.nextDouble();
					System.out.printf("Luas Jajargenjang = %.3f\n", alas * tinggi);
					break;
				}
				default :
					throw new RuntimeException("nomor bangun datar tidak valid");
			}
			break;
		}
		case 2:{
			//bangun ruang
			System.out.println("1. Prisma segitiga");
			System.out.println("2. Tabung");
			System.out.print("Silahkan pilih jenis bangun ruang = ");
			int bangunRuang = sc.nextInt();
			
			switch(bangunRuang){
				case 1:{
					// Prisma Segitiga
					System.out.println("Input alas segitiga pada tutup prisma");
					double alas = sc.nextDouble();
					System.out.println("Input tinggi segitiga pada tutup prisma");
					double tinggi = sc.nextDouble();
					double luasAlas = alas * tinggi / 2.0;
					System.out.println("Input tinggi prisma");
					double tinggiPrisma = sc.nextDouble();
					System.out.printf("Volume Prisma Segitiga = %.3f\n", luasAlas * tinggiPrisma);
					break;
				}
				case 2:{
					// Tabung
					System.out.println("Input jari-jari lingkaran pada tutup prisma");
					double jariJari = sc.nextDouble();
					double luasAlas = Math.PI * jariJari * jariJari;
					System.out.println("Input tinggi");
					double tinggi = sc.nextDouble();
					System.out.printf("Volume Tabung = %.3f\n", luasAlas * tinggi);
					break;
				}
			default:
				throw new RuntimeException("nomor bangun ruang tidak valid");
			}
			break;
		}
	
	}
//		}catch(Exception e) {
//			String alasan = e.getMessage();
//			if(alasan==null)
//				alasan = "";
//			System.out.println("input tidak valid: " +alasan);
//		}
	}
	}

