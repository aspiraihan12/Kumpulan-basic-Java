
public class Tipe_Data_Number {

	public static void main(String[] args) {
	
		//bulat
		byte iniByte = 100;
		short iniShort = 1000;
		int iniInt =1000000000;
		long iniLong = 1000000000;
		long iniLong2 = 10000000000L;

		//pecahan
		float iniFloat;
		double iniDouble = 10.10;
		
		//binary
		int decimalInt = 34;
		int hexaDecimal = 0xFFFFFF;
		int binaryDecimal = 0b1010101;
		
		//angka pakai pemisah
		int amount =1_000_000_000;
	}

}
