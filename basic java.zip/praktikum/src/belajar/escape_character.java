
public class escape_character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("jum\'at");
	}

}
