
public class Panah {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		int n=15;//ukuran (odd)
		int c1 = (n-1)/2; //cond
		int c2 = 3*n/2-1;//cond
		
		for(i=0; i<n;i++) {
			for(j=0;j<n;j++) {
				if(j-i==c1||i+j==c2||i==c1){
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
	}

}
