package praktikum_08;
class Lingkaran {

	private double radius;
	public double IsiJari;
	public  void IsiJari(double radius) {
		this.radius=radius;
	}
	public double Pi() {
		return 3.14;
	}
	public double perolehKeliling() {
		return 2 * Pi() * radius;
	}
	public double luasKeliling() {
		return Pi()*radius*radius;
	}
}
