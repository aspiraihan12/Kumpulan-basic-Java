package praktikum_08;

class PersegiPanjang {
 //kelas persegi panjang mempunyai dua atribut
	public int panjang;
	public int lebar;
	public void setPanjang(int nilaiBaru) {
		panjang = nilaiBaru;
	}
	public void setLebar(int nilaiBaru) {
		lebar = nilaiBaru;
	}
	public int hitungLuas() {
		return panjang*lebar;
	}
	public int hitungKeliling() {
		return 2*(panjang+lebar);
	}
}
public class Panjang{

}
