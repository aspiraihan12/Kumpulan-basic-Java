package praktikum_08;

public class DemoKotak {

	public static void main(String[] args) {
		Kotak k1,k2,k3;
		
		//instasi objek
		k1 = new Kotak();
		k2 = new Kotak();
		k3 = new Kotak();
		
		//mengisi nilai objek 1
		k1.panjang=1;
		k1.lebar=3;
		k1.tinggi=2;
		
		//mengisi nilai objek 2
				k2.panjang=4;
				k2.lebar=5;
				k2.tinggi=2;
				//mengisi nilai objek 1
				k3.panjang=9;
				k3.lebar=3;
				k3.tinggi=2;
				//memanggil metod cetak volume
			k1.cetakVolume();
			k2.cetakVolume();
			k3.cetakVolume();
	}

}
