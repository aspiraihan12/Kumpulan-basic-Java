package praktikum_08;

class Kotaks {
	double panjang;
	double lebar;
	double tinggi;
	
}
