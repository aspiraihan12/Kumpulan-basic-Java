package praktikum_08;

import java.util.Scanner;

public class PenentuLingkaran {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Lingkaran li = new Lingkaran();
		System.out.print("Masukkan Jari = ");
		li.IsiJari = input.nextDouble();
		
		System.out.println("Keliling = "+2*li.Pi()*li.IsiJari);
		System.out.println("Luas = "+li.Pi()*li.IsiJari*li.IsiJari);
		
}
}