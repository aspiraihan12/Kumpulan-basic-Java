package praktikum_08;

class ObjekKotak {
	public static void main(String[] args) {
		double volume;
		Kotaks k = new Kotaks();
		
		//mengisikan nilai kedalam data data kelas kotak
		k.panjang = 5;
		k.lebar = 3;
		k.tinggi=2;
		
		//menghitung isi/volume kotak
		volume = k.panjang*k.tinggi*k.lebar;
		//menampilkan nilai volume ke layar monitor
		System.out.println("Volume kotak = "+volume);
	}
}
