package praktikum_08;

public class Demo_BelajarKelas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	PersegiPanjang PP = new PersegiPanjang();
	PP.setLebar(5);
	PP.setPanjang(3);
	System.out.println("Luas    = "+PP.hitungLuas());
	System.out.println("Keliling    = "+PP.hitungKeliling());
		
	}

}
