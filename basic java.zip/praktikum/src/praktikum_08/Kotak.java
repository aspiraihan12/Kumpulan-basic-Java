package praktikum_08;

class Kotak {
double panjang;
double lebar;
double tinggi;
void cetakVolume() {
	System.out.println("Volume Kotak = "+(panjang*lebar*tinggi));
}
}
