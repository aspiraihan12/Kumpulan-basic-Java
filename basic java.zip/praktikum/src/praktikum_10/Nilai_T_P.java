package praktikum_10;

import java.util.Scanner;

public class Nilai_T_P {
	static double Teori(double n) {
		Scanner a = new Scanner(System.in);
		System.out.print("Masukkan nilai tugas = ");
		double Tugas = a.nextDouble();
		System.out.print("Masukkan nilai kehadiran(1-100) = ");
		double Kehadiran = a.nextDouble();
		System.out.print("Masukkan nilai perilaku = ");
		double Perilaku = a.nextDouble();
		System.out.print("Masukkan nilai UTS = ");
		double uts = a.nextDouble();
		System.out.print("Masukkan nilai UAS = ");
		double uas = a.nextDouble();
		double na = (Kehadiran*0.1)+(Perilaku*0.1)+(Tugas*0.2)+(uts*0.25)+(uas*0.35);
		System.out.println(Konversi(na));
		return na;
	}
	static double Praktik(double n) {
		Scanner a = new Scanner(System.in);
		System.out.print("Masukkan nilai kehadiran(1-100) = ");
		double Kehadiran = a.nextDouble();
		System.out.print("Masukkan nilai perilaku = ");
		double Perilaku = a.nextDouble();
		System.out.print("Masukkan nilai UAS = ");
		double uas = a.nextDouble();
		System.out.print("Masukkan nilai Praktikum = ");
		double ptk = a.nextDouble();
		double na = (Kehadiran*0.1)+(Perilaku*0.1)+(uas*0.3)+(ptk*0.5);
		System.out.println(Konversi(na));
		return na;
	}
	static char Konversi(double na) {
		char k=0;
	
		if(na>=80) {
			System.out.print("A");
		}
		else if(na>=70) {
			System.out.print("B");
	}
		else if(na>=50) {
			System.out.print("C");
	}
		else if(na>=30) {
			System.out.print("D");
	}else
		System.out.print("E");
	return k;
}
	public static void main(String[] args) {
		System.out.println("Pilih jenis mata kuliah =");
		System.out.println("1. teori");
		System.out.println("2. praktek");
		Scanner a = new Scanner(System.in);
		int mk = a.nextInt();
		if (mk==1) {
			System.out.println("Nilai akhirnya adalah = "+Teori(1));
		}else {
			System.out.println("Nilai akhirnya adalah = "+Praktik(1));
		}
	}
}
