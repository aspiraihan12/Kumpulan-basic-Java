package praktikum_10;

import java.util.Scanner;

public class nilai_Teori_DLL {
	public static void main(String [] args) {
		String grade;
		System.out.println("Teori");
		System.out.println("Praktikum");
		System.out.println("jenis mata kuliah");
		System.out.println();
		Scanner input=new Scanner(System.in);
		
		System.out.print("input kehadiran = ");
		int hadir = input.nextInt();
		
		System.out.print("Input perilaku = ");
		int perilaku = input.nextInt();
		
		System.out.print("input praktikum = ");
		int prak = input.nextInt();
		
		System.out.print("UAS = ");
		int ua = input.nextInt();
		
		double nilai = (0.10*hadir)+(0.10*perilaku)+(0.50*prak)+(0.30*ua);
		
		if(nilai >=80){
			grade= "A" ;
			}
			else if (nilai >=70){
			grade= "B" ;
			}

			else if (nilai >=50){
			grade= "C" ;
			}
			else if (nilai >=30){
			grade= "D" ;
			}
			else{
			grade="E" ;

			}
		System.out.println("Nilai kehadiran * 10%  =" + hadir);
		System.out.println ("Nilai perilaku * 10%  =" + perilaku );
		System.out.println("Nilai praktikum * 50%  = " + prak );
		System.out.println("Nilai uas * 30% = " + ua );

		System.out.println("memperoleh nilai akhir sebesar " + nilai);
		System.out.println("Grade nilai yang didapat adalah" + " " + grade);
	}
	
}
