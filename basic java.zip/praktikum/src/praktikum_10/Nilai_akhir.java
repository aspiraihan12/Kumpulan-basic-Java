package praktikum_10;

import java.util.Scanner;

public class Nilai_akhir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String grade;
		double n1,n2,n3,nn ;
	

		Scanner input = new Scanner(System.in);
		System.out.println("PROGRAM HITUNG NILAI AKHIR");
		System.out.println("Input");

		System.out.print("Nilai rata rata tugas : ");
		n1=input.nextDouble();

		System.out.print("Nilai UTS: ");
		n2=input.nextDouble();

		System.out.print("Nilai UAS : ");
		n3=input.nextDouble();
		
		nn = (0.30*n1)+(0.30*n2)+(0.40*n3);
		//m1= 0.30 * n1;
		//m2= 0.30 * n2;
		//m3= 0.40 * n3;
		//mm= m1+m2+m3;

		if(nn >=85){
		grade= "A" ;
		}
		else if (nn >=70){
		grade= "B" ;
		}

		else if (nn >=50){
		grade= "C" ;
		}
		else if (nn >=40){
		grade= "D" ;
		}
		else{
		grade="E" ;

		}

		System.out.println("Dengan Nilai Persentasi Yang dihasilkan" );
		System.out.println("Nilai Rata Rata tugas * 30% =" + (double)n1);
		System.out.println ("Nilai UTS * 30% =" + (double)n2 );
		System.out.println("Nilai UAS * 40% = " + (double)n3 );

		System.out.println("memperoleh nilai akhir sebesar " + nn);
		System.out.println("Grade nilai yang didapat adalah" + " " + grade);

	}

}
