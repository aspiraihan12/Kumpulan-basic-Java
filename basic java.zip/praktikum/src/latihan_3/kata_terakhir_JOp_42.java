package latihan_3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.swing.JOptionPane;

public class kata_terakhir_JOp_42 {
	public static void main(String[] args) {
		BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));
		
		String word1,word2;
		
		word1 = JOptionPane.showInputDialog("Enter Word 1");
		word2 = JOptionPane.showInputDialog("Enter Word 2");
		
		String pesan = word1+" "+word2+" "+"Hello";
		JOptionPane.showMessageDialog(null, pesan);
	
	}
}
