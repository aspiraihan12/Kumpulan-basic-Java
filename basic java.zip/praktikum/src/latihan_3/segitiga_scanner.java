package latihan_3;

import java.util.Scanner;

public class segitiga_scanner {
public static void main(String[] args) {
	Scanner input=new Scanner(System.in);
	double alas,tinggi;
	double luas;
	
	System.out.print("Masukkan Alas :");
	alas=input.nextDouble();
	System.out.print("Masukkan tinggi :");
	tinggi=input.nextDouble();
	
	luas=0.5*alas*tinggi;
	System.out.println("Luas Segitiga : "+luas);
}
}
