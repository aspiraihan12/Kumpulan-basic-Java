package latihan5;

public class seminggu_string_array_perulangan_for {
	public static void main(String[]args) {
		String days[] = {"monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
		for (int i =0; i<7;i++) {
			System.out.println(days[i]);
		}
	}
}
