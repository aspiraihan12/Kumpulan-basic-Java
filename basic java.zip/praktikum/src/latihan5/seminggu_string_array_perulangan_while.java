package latihan5;

public class seminggu_string_array_perulangan_while {
	public static void main(String[] args) {
		int i = 0;
		String days[]= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
		
		while(i<7) {
			System.out.println(days[i]);
			i++;
		}
	}
}
