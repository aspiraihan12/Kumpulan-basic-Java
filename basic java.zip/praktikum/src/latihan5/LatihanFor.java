package latihan5;

public class LatihanFor {
	public static void main(String [] args) {
		int bil;
		for(bil=125; bil<=200; bil+=5) {
			System.out.println (bil);
		}
	}
}
