package latihan5;

public class buku_alamat_StringArray {
	public static void main(String[] args) {
		String alamat[][]= {{"Florence","735-1234","Manilla"},
	    {"Joyce","983-3333","Quezon City"},{"Becca","456-3322","Manilla"}};
		
		int i=0;
		do {
			System.out.println("Name	:"+alamat[i][0]);
			System.out.println("Tel. #  :"+alamat[i][1]);
			System.out.println("Addres  :"+alamat[i][2]);
			System.out.println("");
			i++;
		}while(i<3);
	}
}
