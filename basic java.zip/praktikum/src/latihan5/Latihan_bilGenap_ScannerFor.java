package latihan5;

import java.util.Scanner;

public class Latihan_bilGenap_ScannerFor {
	public static void main(String [] args) {
		Scanner inputan = new Scanner(System.in);
		System.out.println("Bilangan Genap");
		System.out.print("Masukkan batas bilangan genap :");
		 int batas = inputan.nextInt();
		 System.out.println("Hasil: ");
		
		for(int i =1; i<=batas; i++) {
			if(i % 2 == 1)
				continue;
			System.out.print( i +",");
		}
		
	}
	}
	
