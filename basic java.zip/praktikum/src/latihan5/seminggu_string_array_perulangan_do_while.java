package latihan5;

public class seminggu_string_array_perulangan_do_while {
public static void main(String [] args) {
	String days[]= {"monday","tuesday","wednes","thursday","friday","saturday","sunday"};
	int i=0;
	do {
		System.out.println(days[i]);
		i++;
	}while(i<7);
}
}
