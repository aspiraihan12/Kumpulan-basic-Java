package praktikum_04;

import java.util.Scanner;

public class PernyataanSwitch_05 {
	public static void main(String[] args) {
		System.out.println("~Menu Pilihan");
		System.out.println("1. Soto Ayam");
		System.out.println("2. Nasi Rawon");
		System.out.println("3. Gulai Kambing");
		System.out.println("4. sate Kambing");
		System.out.println("");
		
		System.out.print("Silahkan pilih menu: ");
		Scanner input = new Scanner(System.in);
		int pilihan = input.nextInt();
		switch (pilihan) {
		case 1:
			System.out.println("Pilihan Anda Soto Ayam");
			System.out.println("Silakan menunggu sebentar");
			break;
		case 2:
			System.out.println("Pilihan Anda Nasi Rawon");
			System.out.println("Silakan menunggu sebentar");
			break;
		case 3:
			System.out.println("Pilihan Anda Gulai Kambing");
			System.out.println("Silakan menunggu sebentar");
			break;
		case 4:
			System.out.println("Pilihan Anda sate Kambing");
			System.out.println("Silakan menunggu sebentar");
			break;
		}
		
		System.out.println("Akhir switch");
		
		}
		
	}

