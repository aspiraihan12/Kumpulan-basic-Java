package praktikum_04;

public class grade_02_switch_Case {
	public static void main(String [] args) {
		int grade=89;
		switch(grade) {
		case 100:
			System.out.println("Exceleent!");
			break;
		case 90:
			System.out.println("Good job!");
			break;
		case 80:
			System.out.println("Study harder!");
			break;
			default:
				System.out.println("Sorry,you failed");
		}
	}
}
