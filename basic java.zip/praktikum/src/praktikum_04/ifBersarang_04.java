package praktikum_04;

import java.util.Scanner;

public class ifBersarang_04 {
	public static void main(String[] args) {
		System.out.print("Nilai  Ujian =");
		Scanner input = new Scanner(System.in);
		double nilaiUjian =input.nextDouble();
		char skor;
		
		if (nilaiUjian >= 90)
		skor ='A';
		else if (nilaiUjian >= 80)
			skor='B';
		else if (nilaiUjian >= 60)
			skor = 'C';
		else if (nilaiUjian >= 50)
			skor = 'D';
		else
			skor ='E';
		System.out.println("Skor = "+skor);
	}
}
