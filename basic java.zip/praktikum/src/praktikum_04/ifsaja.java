package praktikum_04;

public class ifsaja {
public static void main(String [] args) {
	
	int grade=55;
	if(grade>60) {
		System.out.println("Selamat!");
		System.out.println("Anda berhasil!");
	}else
		System.out.println("maaf anda gagal!");
}

}