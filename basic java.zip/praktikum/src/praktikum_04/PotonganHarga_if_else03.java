package praktikum_04;

import java.util.Scanner;

public class PotonganHarga_if_else03 {
	public static void main(String[] args) {
		System.out.print("Total Belanja = Rp ");
		Scanner input = new Scanner(System.in);
		
		int totalBelanja = input.nextInt();
		int diskon;
		
		if(totalBelanja >= 100000)
			diskon = totalBelanja/10;
		else diskon = 0;
		System.out.println("diskon = Rp "+diskon);
	}
}
