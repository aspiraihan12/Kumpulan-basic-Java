package praktikum_04;

import java.util.Scanner;

public class inputan_luar {
	public static void mainASpi() {	
		int grade=89;
		switch(grade) {
		case 100:
			System.out.println("Exceleent!");
			break;
		case 90:
			System.out.println("Good job!");
			break;
		case 80:
			System.out.println("Study harder!");
			break;
			default:
				System.out.println("Sorry,you failed");
		}
	}
public static void main(String[] args) {
	
	System.out.print("Masukkan nilai");
	Scanner input= new Scanner(System.in);
	int grade = input.nextInt();

}
}
