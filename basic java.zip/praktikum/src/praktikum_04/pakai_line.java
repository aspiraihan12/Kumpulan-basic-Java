package praktikum_04;

import java.util.Scanner;

public class pakai_line {
	public static void main(String[] args) {
		String nama="";
		Scanner input = new Scanner(System.in);
		
		System.out.print("Masukkan nama kamu :");
		nama = input.nextLine();
		
		System.out.println("nama kamu adalah"+ nama);
	}
}
