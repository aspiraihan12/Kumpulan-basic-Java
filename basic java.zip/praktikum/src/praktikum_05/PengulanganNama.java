package praktikum_05;

import java.util.Scanner;

public class PengulanganNama {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x =0 ;
		while(x<5) {
			String nama ="";
			Scanner input = new Scanner(System.in);
			System.out.println("Nama : "+nama);
			x++;
			nama = input.next();
		}

	}

}
