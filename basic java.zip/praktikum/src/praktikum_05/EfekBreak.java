package praktikum_05;

public class EfekBreak {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int bil;
for(bil=1;bil<=10;bil++) {
	if(bil==5)
		break;
	
	System.out.println(bil);
}
	}

}
