package praktikum_05;

import java.util.Scanner;

public class For_genap_inputScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		int bil ;
		bil= input.nextInt();
		
		if(bil%2==0) {
			System.out.print("Bilangan "+bil+ "genap");
			
		}else {
			System.out.print("bilangan"+bil+"bukan genap");
		}

	}

}
