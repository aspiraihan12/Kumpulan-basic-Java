package praktikum_05;

public class array_length {
	public static void main(String[] args) {
		int ages[] = new int[100];
		for(int i=0; i<ages.length; i++) {
			System.out.print(ages[i]);
		}
	}
}
