package praktikum_05;

import javax.swing.JOptionPane;

public class inputan_for_JO {
	  public static void main(final String [] args) {
          int nilai ;
          String str = JOptionPane.showInputDialog(null,"\n Masukkan Nilai :");
          nilai =Integer.parseInt(str);
          
          System.out.println("\n Banyak Looping " +nilai );  
          int i ;
          for(i = 1;i <= nilai ; i++) {
          System.out.println("\t \n Perulangan ke " +i); 
          }
    }
}
