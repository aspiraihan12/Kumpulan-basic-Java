package praktikum_05;

import java.util.Scanner;

public class DoWhile {
public static void main(String[]args) {
	Scanner data = new Scanner(System.in);
	int i= 1;
	float n, jum =0,x=0,rata;
	System.out.println("banyak data:  ");
	n=data.nextFloat();
	
	do {
		System.out.println("data ke- "+i);
		x=data.nextFloat();
		jum +=x;
		i++;
	}while(i<=n);
	System.out.println("jumlah = "+jum);
	System.out.println("Rata-rata = "+(jum/n));
}
}
