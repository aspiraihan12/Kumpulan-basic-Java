package praktikum_05;

public class PenyataanFor {
public static void main(String [] args) {
	
	for(int bil=0; bil<20; bil+=2) {
		System.out.println(bil);
	}
}
}
