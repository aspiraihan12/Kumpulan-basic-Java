package praktikum_05;

import javax.swing.JOptionPane;

public class InputPengulanganFor {
 static int n;
  static void masukan() {
	  String msk = JOptionPane.showInputDialog("Masukkan n perulangan");
	  n=Integer.parseInt(msk);
  }
  static void proses() {
	  for(int i=0; i<=n; i++) {
		  System.out.println("i = "+i);
	  }
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		masukan();
		proses();
	}

}
