package praktikum_05;

public class ContohDoWhile {
public static void main(String[] args) {
	int bil =1;
	do {
		System.out.println("Java");
		bil++;
	}while(bil<=8);
}
}
