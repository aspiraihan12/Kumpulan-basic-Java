package praktikum_05;

public class CobaWhile {
	public static void main(String [] args) {
		int jumlah = 1;
		
		while(jumlah <= 5) {
			System.out.println("Java");
			System.out.println("aspi");
			jumlah++;
		}
	}
}
